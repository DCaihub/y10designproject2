//JS for Typing Effect
//establishes variables and some functions
var TxtType = function(el, toRotate, period) {
    this.toRotate = toRotate;
    this.el = el;
    this.loopNum = 0;
    this.period = parseInt(period, 10) || 2000;
    this.txt = '';
    this.tick();
    this.isDeleting = false;
};
//creates array for the letters inside the words that will be typed
TxtType.prototype.tick = function() {
    var i = this.loopNum % this.toRotate.length;
    var fullTxt = this.toRotate[i];

    if (this.isDeleting) {
        this.txt = fullTxt.substring(0, this.txt.length - 1);
//typing text        
    } else {
        this.txt = fullTxt.substring(0, this.txt.length + 1);
    }
//html
    this.el.innerHTML = '<span class="wrap">'+this.txt+'</span>';

    var that = this;
    var delta = 200 - Math.random() * 100;

    if (this.isDeleting) { delta /= 2; }
//deleting text
    if (!this.isDeleting && this.txt === fullTxt) {
        delta = this.period;
        this.isDeleting = true;
    } else if (this.isDeleting && this.txt === '') {
        this.isDeleting = false;
        this.loopNum++;
        delta = 500;
    }
//wait before deleting
    setTimeout(function() {
        that.tick();
    }, delta);
};

window.onload = function() {
    var elements = document.getElementsByClassName('typewrite');
    for (var i=0; i<elements.length; i++) {
        var toRotate = elements[i].getAttribute('data-type');
        var period = elements[i].getAttribute('data-period');
        if (toRotate) {
            new TxtType(elements[i], JSON.parse(toRotate), period);
        }
    }
    var css = document.createElement("style");
    css.type = "text/css";
    css.innerHTML = ".typewrite > .wrap { border-right: 0.08em solid #fff}";
    document.body.appendChild(css);
};

//JS Carousel - Annotated in planning materials
currentSlide = 1;
showSlides(currentSlide);

function plusSlides(n){
    showSlides(currentSlide += n);
}
function currentSlide(n){
    showSlides(currentSlide = n);
}
function showSlides(n){
    let i;
    var slides = document.getElementsByClassName("slide");
    var dots = document.getElementsByClassName("dot");
    if (n > slides.length){
        currentSlide = 1
    }
    if (n < 1){
        currentSlide = slides.length;
    }
    for (i=0; i < slides.length; i++){
        slides[i].style.display = "none";
    }
    for (i=0; i < dots.length; i++){
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[currentSlide-1].style.display = "block";
    dots[currentSlide-1].className += " active";
}

//search bar JS

function search() { 
    //gets user input
    if (document.getElementById("search")) {
        userInput = (document.getElementById("search").value).toLowerCase(); 
    }
    //checks if user input is a specific phrase. If it is a valid phraase, it will open the page associated with the phrase. 
    if (userInput == "basi" ||   userInput == "Basi" || userInput == "sweet potato" || userInput == "Sweet potato" || userInput == "abbrevname" || userInput == "Abrrevname") { 
        window.open("Dish1.html", "_self"); 
    }
   
    else if (userInput == "sweet and sour" || userInput == "guobaorou" || userInput == "pork" || userInput == "Pork") { 
        window.open("Dish2.html", "_self"); 
    }

    else if (userInput == "pickled cabbage" || userInput == "soup" || userInput == "lamb" || userInput == "suancai") { 
        window.open("Dish3.html", "_self"); 
    }

    else if (userInput == "chaoxian" || userInput == "Cold noodles" || userInput == "korean" || userInput == "Korean" || userInput =="Cold Noodles") { 
        window.open("Dish4.html", "_self"); 
    }

	else if (userInput == "culture" || userInput == "Culture" || userInput == "Learn More" || userInput == "influences" || userInput == "Influences" || userInput == "About" || userInput == "about") { 
        window.open("about.html", "_self"); 
    }

    else if (userInput == "home" || userInput == "Home" || userInput == "Home Page" || userInput == "home page" || userInput == "Homepage" || userInput == "homepage") { 
        window.open("index.html", "_self"); 
    }

	else if (userInput == "sources" || userInput == "Sources" || userInput == "bibliography" || userInput == "Bibliography" || userInput == "information" || userInput == "Information") { 
        window.open("https://docs.google.com/document/u/0/d/1SqDqhiw9Jn3wovFhQdrMSW0p7t8LJUSIUF-x2nqfeQ4/edit", "_self"); 
    }

    else if (userInput == "maps" || userInput == "Maps" || userInput == "near me" || userInput == "Near me" || userInput == "restaurants" || userInput == "Restaurants") { 
        window.open("nearme.html", "_self"); 
    }
    //if user enters invalid phrase, it will give them this alert.
    else {
        alert("Please enter a different keyword.\n Try 'About' or 'Korean.'");
    }
}

//script

// Initialize and add the map
function initMap() {
    // define longitude and latitude coordinates of UCC, Chinese Dumpling House, Asian Legend, and Tiger BBQ
    const UCC = { lat: 43.691400, lng: -79.403450 };
    const CDH = { lat: 43.818490, lng: -79.330660};
    const AL = { lat: 43.788010, lng: -79.267418};
    const tiger = { lat: 43.824860, lng: -79.277540};

    // The map, centered at UCC, with zoom 10 (greater zoom number, more zoomed in the map will be)
    const map = new google.maps.Map(document.getElementById("map"), {
      zoom: 10,
      center: UCC,
    });

    // The markers, positioned at respective position on our parent map
    const marker = new google.maps.Marker({
      position: UCC,
      map: map,
    });
    const marker1 = new google.maps.Marker({
        position: CDH,
        map: map,
    });
    const marker2 = new google.maps.Marker({
        position: AL,
        map: map,
    });
      const marker3 = new google.maps.Marker({
        position: tiger,
        map: map,
    });
  }
//spawns maps
  window.initMap = initMap;